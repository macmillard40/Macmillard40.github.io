Mac Weekly Board PWA Bundle

I can't publish a live website from inside this chat, but this bundle is ready to host on:
- GitHub Pages
- Netlify
- Cloudflare Pages
- Vercel

Fastest route:
1. Upload these files to a simple static host.
2. Open the hosted URL in Safari on your iPhone.
3. Tap Share > Add to Home Screen.

Files:
- index.html
- manifest.json
- sw.js
- icon.svg
